export default function helloWorld(): void;
//# sourceMappingURL=dntpm_wolf_impressiveAmaranthEgretba0cab9f7fd4c453_entrypoint.d.ts.map